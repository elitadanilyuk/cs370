Author: Elita Danilyuk

The README quiz was completed in canvas online.

To build and compose the docker container run:
    docker-compose up --build

Dependencies for the server and client are within their perspective requirements.txt files.